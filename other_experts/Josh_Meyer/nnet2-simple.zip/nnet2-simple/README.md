# nnet2-simple

A collection of simple scripts for Kaldi's nnet2.

These scripts go along with the tutorial at:

```
http://jrmeyer.github.io/asr/2016/12/15/DNN-AM-Kaldi.html
```

These scripts are optimized for human-readability and intuition, not performance.