Aishell is an open Chinese Mandarin speech database published by Beijing Shell Shell Technology Co.,Ltd.

400 people from different accent areas in China are invited to participate in the recording, which is conducted in a quiet indoor environment using high fidelity microphone and downsampled to 16kHz. The manual transcription accuracy is above 95%, through professional speech annotation and strict quality inspection. The data is free for academic use. The corpus contains 170 hours of speech, and is devided into training(85%), developement(10%) and testing(5%) sets. The developement set is used to tune the hyperparameters in training.

The database can be downloaded from openslr:
http://www.openslr.org/33/

This folder contains two subfolders:
s5: a speech recognition recipe
v1: a speaker recognition recipe

For more details, please visit:
http://www.aishelltech.com/kysjcp
