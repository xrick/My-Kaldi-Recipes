This is a recipe for CMU's [AN4](http://www.speech.cs.cmu.edu/databases/an4/).

To run, download the Sphere-format database from the link above and extract the files (`tar xvfz an4_sphere.tar.gz`). Then edit `an4_root` in `run.sh` to point to the AN4 directory.
